public class RelatorioRequest
{
    public string ClienteId { get; set; }
    public string DataInicial { get; set; }
    public string DataFinal { get; set; }
    public string Tipo { get; set; } 
}
